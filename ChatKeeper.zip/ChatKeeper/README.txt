ChatKeeper - personal WhatsApp notification + voice note saver (Android, Kotlin)

1. Open this folder in Android Studio (Koala or newer), let Gradle sync.
2. Run on your phone (USB debugging) or Build > Build APK.
3. In the app: allow Notification access, All files access, disable battery optimization.
4. Messages are saved when the notification arrives. Voice notes are copied from
   WhatsApp's folder ~15s and ~2min after a notification, and every 15 min.
