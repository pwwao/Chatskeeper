package com.pwwao.chatkeeper

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.view.WindowManager
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    private var tick by mutableIntStateOf(0)
    private var unlocked by mutableStateOf(false)
    private var stoppedAt = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Lock.secure(this)) window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        Prefs.firstRun(this)
        Scan.periodic(this)
        Sync.periodic(this)
        setContent {
            MaterialTheme {
                if (unlocked) App(tick) else LockScreen { unlocked = true }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        if (stoppedAt != 0L && System.currentTimeMillis() - stoppedAt > 10_000) unlocked = false
    }

    override fun onStop() {
        super.onStop()
        stoppedAt = System.currentTimeMillis()
    }

    override fun onResume() {
        super.onResume()
        tick++
        Scan.soon(this)
    }
}

@Composable
fun LockScreen(onUnlock: () -> Unit) {
    val ctx = LocalContext.current
    val setup = remember { !Lock.isSet(ctx) }
    var code by remember { mutableStateOf("") }
    var first by remember { mutableStateOf<String?>(null) }
    var msg by remember { mutableStateOf("") }

    Column(
        Modifier.fillMaxSize().statusBarsPadding().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Timescale", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        Text(when {
            setup && first == null -> "Create a passcode (4 to 8 digits)"
            setup -> "Confirm your passcode"
            else -> "Enter passcode"
        })
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = code,
            onValueChange = { if (it.length <= 8 && it.all(Char::isDigit)) code = it },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)
        )
        if (msg.isNotEmpty()) Text(msg, color = Color.Red, modifier = Modifier.padding(top = 8.dp))
        Spacer(Modifier.height(12.dp))
        Button(onClick = {
            if (setup) {
                if (first == null) {
                    if (code.length < 4) msg = "Use at least 4 digits" else { first = code; code = ""; msg = "" }
                } else if (code == first) {
                    Lock.set(ctx, code)
                    onUnlock()
                } else {
                    msg = "Passcodes did not match. Start again."
                    first = null; code = ""
                }
            } else {
                val wait = Lock.waitSeconds(ctx)
                if (wait > 0) {
                    msg = "Try again in ${wait}s"
                } else if (Lock.check(ctx, code)) {
                    onUnlock()
                } else {
                    val w = Lock.waitSeconds(ctx)
                    msg = if (w > 0) "Wrong passcode. Try again in ${w}s" else "Wrong passcode"
                    code = ""
                }
            }
        }) { Text(if (setup && first == null) "Next" else if (setup) "Save" else "Unlock") }
    }
}

private fun fmt(t: Long) = SimpleDateFormat("d MMM, HH:mm", Locale.getDefault()).format(Date(t))

private fun openFile(ctx: Context, path: String) {
    try {
        val f = File(path)
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", f)
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "*/*"
        ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
    } catch (_: Exception) {
        Toast.makeText(ctx, "No app found to open this file", Toast.LENGTH_SHORT).show()
    }
}

@Composable
fun App(tick: Int) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dao = remember { Db.get(ctx).dao() }
    var tab by remember { mutableIntStateOf(0) }
    var q by remember { mutableStateOf("") }
    var showSync by remember { mutableStateOf(false) }
    var url by remember { mutableStateOf(Prefs.url(ctx)) }
    var key by remember { mutableStateOf(Prefs.key(ctx)) }
    var syncOn by remember { mutableStateOf(Prefs.syncOn(ctx)) }
    var secureOn by remember { mutableStateOf(Lock.secure(ctx)) }
    var newCode by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf<Pair<String, () -> Unit>?>(null) }
    val msgs by remember(q) { dao.search(q) }.collectAsState(initial = emptyList())
    val voices by dao.voices().collectAsState(initial = emptyList())
    val others by dao.otherMedia().collectAsState(initial = emptyList())

    val listenerOn = remember(tick) { NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName) }
    val filesOn = remember(tick) { Environment.isExternalStorageManager() }

    fun ask(text: String, act: () -> Unit) { confirm = text to act }
    fun run(block: suspend () -> Unit) { scope.launch(Dispatchers.IO) { block() } }

    val player = remember { arrayOfNulls<MediaPlayer>(1) }
    fun play(path: String) {
        try {
            player[0]?.release()
            player[0] = MediaPlayer().apply { setDataSource(path); prepare(); start() }
        } catch (_: Exception) { }
    }
    DisposableEffect(Unit) { onDispose { player[0]?.release() } }

    confirm?.let { (text, act) ->
        AlertDialog(
            onDismissRequest = { confirm = null },
            title = { Text("Delete?") },
            text = { Text(text) },
            confirmButton = { TextButton(onClick = { act(); confirm = null }) { Text("Delete", color = Color.Red) } },
            dismissButton = { TextButton(onClick = { confirm = null }) { Text("Cancel") } }
        )
    }

    Column(Modifier.fillMaxSize().statusBarsPadding().padding(12.dp)) {
        Text("Timescale", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)

        if (!listenerOn || !filesOn) {
            Card(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Finish setup")
                    if (!listenerOn) Button(onClick = {
                        ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                    }) { Text("1. Allow notification access") }
                    if (!filesOn) Button(onClick = {
                        ctx.startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                            Uri.parse("package:${ctx.packageName}")))
                    }) { Text("2. Allow all files access (media)") }
                }
            }
        }
        OutlinedButton(onClick = {
            ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }, Modifier.fillMaxWidth()) { Text("Disable battery optimization") }

        OutlinedButton(onClick = { showSync = !showSync }, Modifier.fillMaxWidth()) { Text("Sync & data settings") }
        if (showSync) {
            Card(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Sync to server", Modifier.weight(1f))
                        Switch(checked = syncOn, onCheckedChange = {
                            syncOn = it
                            Prefs.setSync(ctx, it)
                            if (it) Sync.now(ctx)
                        })
                    }
                    OutlinedTextField(url, { url = it }, Modifier.fillMaxWidth(),
                        label = { Text("Server URL (https://...)") }, singleLine = true)
                    OutlinedTextField(key, { key = it }, Modifier.fillMaxWidth(),
                        label = { Text("Secret key") }, singleLine = true)
                    Button(onClick = {
                        Prefs.save(ctx, url, key)
                        Sync.now(ctx)
                        Toast.makeText(ctx, if (syncOn) "Saved. Sync started" else "Saved. Sync is off", Toast.LENGTH_SHORT).show()
                    }) { Text("Save & sync now") }
                    OutlinedButton(onClick = {
                        ask("Delete ALL saved messages, voice notes and media from this phone (and from the server when sync is on)?") {
                            run { Deleter.all(ctx) }
                        }
                    }) { Text("Delete ALL saved data", color = Color.Red) }
                }
            }
        }

        TabRow(selectedTabIndex = tab) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Messages") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Voice") })
            Tab(selected = tab == 2, onClick = { tab = 2 }, text = { Text("Media") })
        }

        when (tab) {
            0 -> {
                OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth().padding(vertical = 6.dp),
                    placeholder = { Text("Search sender or text") }, singleLine = true)
                LazyColumn {
                    items(msgs, key = { it.id }) { m ->
                        Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                            Row {
                                Text(m.sender, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                Text(fmt(m.time), style = MaterialTheme.typography.bodySmall)
                            }
                            Text(m.text)
                            if (m.deleted) Text("Deleted by sender", color = Color.Red, style = MaterialTheme.typography.labelSmall)
                            Row {
                                TextButton(onClick = { run { Deleter.msg(ctx, m) } }) { Text("Delete") }
                                TextButton(onClick = {
                                    ask("Delete all saved messages from ${m.sender}?") { run { Deleter.chat(ctx, m.app, m.sender) } }
                                }) { Text("Delete chat") }
                            }
                        }
                        HorizontalDivider()
                    }
                }
            }
            1 -> Column {
                if (voices.isNotEmpty()) TextButton(onClick = {
                    ask("Delete all saved voice notes?") { run { Deleter.voices(ctx) } }
                }) { Text("Delete all voice notes", color = Color.Red) }
                LazyColumn {
                    items(voices, key = { it.id }) { v ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(v.app, fontWeight = FontWeight.Bold)
                                Text(fmt(v.time), style = MaterialTheme.typography.bodySmall)
                            }
                            Button(onClick = { play(v.saved) }) { Text("Play") }
                            TextButton(onClick = { run { Deleter.media(ctx, v) } }) { Text("Delete") }
                        }
                        HorizontalDivider()
                    }
                }
            }
            else -> Column {
                if (others.isNotEmpty()) TextButton(onClick = {
                    ask("Delete all saved photos, videos and documents?") { run { Deleter.others(ctx) } }
                }) { Text("Delete all media", color = Color.Red) }
                LazyColumn {
                    items(others, key = { it.id }) { m ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("${m.kind.uppercase()} · ${m.app}", fontWeight = FontWeight.Bold)
                                Text(fmt(m.time), style = MaterialTheme.typography.bodySmall)
                            }
                            Button(onClick = { openFile(ctx, m.saved) }) { Text("Open") }
                            TextButton(onClick = { run { Deleter.media(ctx, m) } }) { Text("Delete") }
                        }
                        HorizontalDivider()
                    }
                }
            }
        }
    }
}
