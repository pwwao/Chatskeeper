package com.pwwao.chatkeeper

import android.content.Context
import android.content.Intent
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationManagerCompat
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    private var tick by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Scan.periodic(this)
        setContent { MaterialTheme { App(tick) } }
    }

    override fun onResume() {
        super.onResume()
        tick++
        Scan.soon(this)
    }
}

private fun fmt(t: Long) = SimpleDateFormat("d MMM, HH:mm", Locale.getDefault()).format(Date(t))

@Composable
fun App(tick: Int) {
    val ctx = LocalContext.current
    val dao = remember { Db.get(ctx).dao() }
    var tab by remember { mutableIntStateOf(0) }
    var q by remember { mutableStateOf("") }
    val msgs by remember(q) { dao.search(q) }.collectAsState(initial = emptyList())
    val voices by dao.voices().collectAsState(initial = emptyList())

    val listenerOn = remember(tick) { NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName) }
    val filesOn = remember(tick) { Environment.isExternalStorageManager() }

    val player = remember { arrayOfNulls<MediaPlayer>(1) }
    fun play(path: String) {
        try {
            player[0]?.release()
            player[0] = MediaPlayer().apply { setDataSource(path); prepare(); start() }
        } catch (_: Exception) { }
    }
    DisposableEffect(Unit) { onDispose { player[0]?.release() } }

    Column(Modifier.fillMaxSize().statusBarsPadding().padding(12.dp)) {
        Text("ChatKeeper", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)

        if (!listenerOn || !filesOn) {
            Card(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Finish setup")
                    if (!listenerOn) Button(onClick = {
                        ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                    }) { Text("1. Allow notification access") }
                    if (!filesOn) Button(onClick = {
                        ctx.startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                            Uri.parse("package:${ctx.packageName}")))
                    }) { Text("2. Allow all files access (voice notes)") }
                }
            }
        }
        OutlinedButton(onClick = {
            ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }, Modifier.fillMaxWidth()) { Text("Disable battery optimization for ChatKeeper") }

        TabRow(selectedTabIndex = tab) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Messages (${msgs.size})") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Voice notes (${voices.size})") })
        }

        if (tab == 0) {
            OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth().padding(vertical = 6.dp),
                placeholder = { Text("Search sender or text") }, singleLine = true)
            LazyColumn {
                items(msgs, key = { it.id }) { m ->
                    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                        Row {
                            Text(m.sender, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            Text(fmt(m.time), style = MaterialTheme.typography.bodySmall)
                        }
                        Text(m.text)
                        if (m.deleted) Text("Deleted by sender", color = Color.Red, style = MaterialTheme.typography.labelSmall)
                    }
                    HorizontalDivider()
                }
            }
        } else {
            LazyColumn {
                items(voices, key = { it.id }) { v ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            Text(v.app, fontWeight = FontWeight.Bold)
                            Text(fmt(v.time), style = MaterialTheme.typography.bodySmall)
                        }
                        Button(onClick = { play(v.saved) }) { Text("Play") }
                    }
                    HorizontalDivider()
                }
            }
        }
    }
}
