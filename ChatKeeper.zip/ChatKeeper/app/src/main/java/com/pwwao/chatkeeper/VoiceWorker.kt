package com.pwwao.chatkeeper

import android.content.Context
import android.os.Environment
import androidx.work.*
import java.io.File
import java.util.concurrent.TimeUnit

private val VOICE_DIRS = mapOf(
    "WhatsApp" to listOf(
        "Android/media/com.whatsapp/WhatsApp/Media/WhatsApp Voice Notes",
        "WhatsApp/Media/WhatsApp Voice Notes"
    ),
    "WhatsApp Business" to listOf(
        "Android/media/com.whatsapp.w4b/WhatsApp Business/Media/WhatsApp Business Voice Notes",
        "WhatsApp Business/Media/WhatsApp Business Voice Notes"
    )
)

class VoiceWorker(c: Context, p: WorkerParameters) : CoroutineWorker(c, p) {
    override suspend fun doWork(): Result {
        if (!Environment.isExternalStorageManager()) return Result.success()
        val dao = Db.get(applicationContext).dao()
        val out = File(applicationContext.filesDir, "voice").apply { mkdirs() }
        val root = Environment.getExternalStorageDirectory()

        for ((app, dirs) in VOICE_DIRS) for (d in dirs) {
            val dir = File(root, d)
            if (!dir.isDirectory) continue
            dir.walkTopDown().filter { it.isFile && it.extension.lowercase() in setOf("opus", "ogg", "m4a", "aac") }
                .forEach { f ->
                    if (dao.hasVoice(f.absolutePath) > 0) return@forEach
                    try {
                        val copy = File(out, "${System.nanoTime()}_${f.name}")
                        f.copyTo(copy, overwrite = true)
                        dao.addVoice(Voice(src = f.absolutePath, saved = copy.absolutePath, app = app, time = f.lastModified()))
                    } catch (_: Exception) { }
                }
        }
        return Result.success()
    }
}

object Scan {
    fun soon(c: Context) {
        val wm = WorkManager.getInstance(c)
        wm.enqueueUniqueWork("vn-soon", ExistingWorkPolicy.KEEP,
            OneTimeWorkRequestBuilder<VoiceWorker>().setInitialDelay(15, TimeUnit.SECONDS).build())
        wm.enqueueUniqueWork("vn-late", ExistingWorkPolicy.KEEP,
            OneTimeWorkRequestBuilder<VoiceWorker>().setInitialDelay(2, TimeUnit.MINUTES).build())
    }

    fun periodic(c: Context) {
        WorkManager.getInstance(c).enqueueUniquePeriodicWork("vn-periodic", ExistingPeriodicWorkPolicy.KEEP,
            PeriodicWorkRequestBuilder<VoiceWorker>(15, TimeUnit.MINUTES).build())
    }
}
