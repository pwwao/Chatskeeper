package com.pwwao.chatkeeper

import android.app.Notification
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import kotlinx.coroutines.*

val APPS = mapOf(
    "com.whatsapp" to "WhatsApp",
    "com.whatsapp.w4b" to "WhatsApp Business"
)

class CaptureService : NotificationListenerService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val noise = Regex("""^\d+ (new )?messages?.*|^checking for new messages.*|^whatsapp web.*""", RegexOption.IGNORE_CASE)

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val app = APPS[sbn.packageName] ?: return
        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val ex = n.extras
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val convTitle = ex.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE)?.toString()
        val chat = convTitle ?: title
        if (chat.isBlank() || chat == "WhatsApp" || chat == "WhatsApp Business") return

        val found = mutableListOf<Msg>()
        @Suppress("DEPRECATION")
        val arr = ex.getParcelableArray(Notification.EXTRA_MESSAGES)
        if (arr != null) {
            val msgs = Notification.MessagingStyle.Message.getMessagesFromBundleArray(arr)
            for (m in msgs) {
                val body = m.text?.toString() ?: continue
                val who = m.senderPerson?.name?.toString()
                val text = if (convTitle != null && who != null) "$who: $body" else body
                found += Msg(app = app, sender = chat, text = text, time = m.timestamp)
            }
        } else {
            val body = ex.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: return
            found += Msg(app = app, sender = chat, text = body, time = sbn.postTime)
        }

        scope.launch {
            val dao = Db.get(applicationContext).dao()
            for (m in found) {
                if (noise.matches(m.text.trim())) continue
                if (m.text.contains("This message was deleted", ignoreCase = true)) {
                    dao.markDeleted(app, chat, m.time)
                } else {
                    dao.addMsg(m)
                }
            }
            Scan.soon(applicationContext)
        }
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
