package com.pwwao.chatkeeper

import android.content.Context
import android.util.Base64
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

object Lock {
    private fun p(c: Context) = c.getSharedPreferences("lock", Context.MODE_PRIVATE)

    private fun hash(code: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(code.toCharArray(), salt, 60000, 256)
        return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
    }

    fun isSet(c: Context) = p(c).getString("h", null) != null

    fun set(c: Context, code: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        p(c).edit()
            .putString("s", Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString("h", Base64.encodeToString(hash(code, salt), Base64.NO_WRAP))
            .putInt("fails", 0).putLong("until", 0L).apply()
    }

    fun waitSeconds(c: Context): Int {
        val left = p(c).getLong("until", 0L) - System.currentTimeMillis()
        return if (left > 0) ((left + 999) / 1000).toInt() else 0
    }

    fun check(c: Context, code: String): Boolean {
        if (waitSeconds(c) > 0) return false
        val sp = p(c)
        val salt = Base64.decode(sp.getString("s", "") ?: "", Base64.NO_WRAP)
        val want = Base64.decode(sp.getString("h", "") ?: "", Base64.NO_WRAP)
        val ok = MessageDigest.isEqual(want, hash(code, salt))
        if (ok) {
            sp.edit().putInt("fails", 0).putLong("until", 0L).apply()
        } else {
            val fails = sp.getInt("fails", 0) + 1
            val delay = if (fails >= 5) minOf((fails - 4) * 30L, 600L) * 1000 else 0L
            sp.edit().putInt("fails", fails).putLong("until", System.currentTimeMillis() + delay).apply()
        }
        return ok
    }

    fun secure(c: Context) = p(c).getBoolean("secure", true)
    fun setSecure(c: Context, on: Boolean) { p(c).edit().putBoolean("secure", on).apply() }
}
