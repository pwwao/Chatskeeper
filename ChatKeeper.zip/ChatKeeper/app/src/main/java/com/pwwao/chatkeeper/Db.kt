package com.pwwao.chatkeeper

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "messages", indices = [Index(value = ["app", "sender", "text", "time"], unique = true)])
data class Msg(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val app: String,
    val sender: String,
    val text: String,
    val time: Long,
    val deleted: Boolean = false
)

@Entity(tableName = "voice", indices = [Index(value = ["src"], unique = true)])
data class Voice(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val src: String,
    val saved: String,
    val app: String,
    val time: Long
)

@Dao
interface KeeperDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun addMsg(m: Msg): Long

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun addVoice(v: Voice): Long

    @Query("SELECT COUNT(*) FROM voice WHERE src = :src")
    suspend fun hasVoice(src: String): Int

    @Query("UPDATE messages SET deleted = 1 WHERE app = :app AND sender = :sender AND time = :time")
    suspend fun markDeleted(app: String, sender: String, time: Long)

    @Query("SELECT * FROM messages WHERE sender LIKE '%' || :q || '%' OR text LIKE '%' || :q || '%' ORDER BY time DESC")
    fun search(q: String): Flow<List<Msg>>

    @Query("SELECT * FROM voice ORDER BY time DESC")
    fun voices(): Flow<List<Voice>>
}

@Database(entities = [Msg::class, Voice::class], version = 1, exportSchema = false)
abstract class Db : RoomDatabase() {
    abstract fun dao(): KeeperDao

    companion object {
        @Volatile private var inst: Db? = null
        fun get(c: Context): Db = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(c.applicationContext, Db::class.java, "keeper.db")
                .build().also { inst = it }
        }
    }
}
