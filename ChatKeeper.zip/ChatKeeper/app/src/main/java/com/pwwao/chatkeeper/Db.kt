package com.pwwao.chatkeeper

import android.content.Context
import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "messages", indices = [Index(value = ["app", "sender", "text", "time"], unique = true)])
data class Msg(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val app: String,
    val sender: String,
    val text: String,
    val time: Long,
    val deleted: Boolean = false,
    @ColumnInfo(defaultValue = "0") val synced: Boolean = false
)

// Table keeps the old name "voice" so existing data survives the upgrade.
@Entity(tableName = "voice", indices = [Index(value = ["src"], unique = true)])
data class Media(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val src: String,
    val saved: String,
    val app: String,
    val time: Long,
    @ColumnInfo(defaultValue = "'voice'") val kind: String = "voice",
    @ColumnInfo(defaultValue = "0") val synced: Boolean = false
)

// Hashes of items the user deleted, so they are not saved again later.
@Entity(tableName = "blocked")
data class Block(@PrimaryKey val h: String)

// Delete requests waiting to be sent to the server.
@Entity(tableName = "dels")
data class Del(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: String,
    val a: String = "",
    val b: String = ""
)

@Dao
interface KeeperDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun addMsg(m: Msg): Long

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun addMedia(v: Media): Long

    @Query("SELECT COUNT(*) FROM voice WHERE src = :src")
    suspend fun hasMedia(src: String): Int

    @Query("UPDATE messages SET deleted = 1, synced = 0 WHERE app = :app AND sender = :sender AND time = :time")
    suspend fun markDeleted(app: String, sender: String, time: Long)

    @Query("SELECT * FROM messages WHERE sender LIKE '%' || :q || '%' OR text LIKE '%' || :q || '%' ORDER BY time DESC")
    fun search(q: String): Flow<List<Msg>>

    @Query("SELECT * FROM voice WHERE kind = 'voice' ORDER BY time DESC")
    fun voices(): Flow<List<Media>>

    @Query("SELECT * FROM voice WHERE kind != 'voice' ORDER BY time DESC")
    fun otherMedia(): Flow<List<Media>>

    @Query("SELECT * FROM messages WHERE synced = 0 LIMIT 200")
    suspend fun unsyncedMsgs(): List<Msg>

    @Query("UPDATE messages SET synced = 1 WHERE id IN (:ids)")
    suspend fun markMsgsSynced(ids: List<Long>)

    @Query("SELECT * FROM voice WHERE synced = 0 LIMIT 10")
    suspend fun unsyncedMedia(): List<Media>

    @Query("UPDATE voice SET synced = 1 WHERE id = :id")
    suspend fun markMediaSynced(id: Long)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun block(b: Block)

    @Query("SELECT COUNT(*) FROM blocked WHERE h = :h")
    suspend fun isBlocked(h: String): Int

    @Query("DELETE FROM messages WHERE id = :id")
    suspend fun delMsg(id: Long)

    @Query("SELECT * FROM messages WHERE app = :app AND sender = :sender")
    suspend fun chatMsgs(app: String, sender: String): List<Msg>

    @Query("DELETE FROM messages WHERE app = :app AND sender = :sender")
    suspend fun delChat(app: String, sender: String)

    @Query("SELECT * FROM messages")
    suspend fun allMsgs(): List<Msg>

    @Query("DELETE FROM messages")
    suspend fun delAllMsgs()

    @Query("SELECT * FROM voice")
    suspend fun allMedia(): List<Media>

    @Query("SELECT * FROM voice WHERE kind = 'voice'")
    suspend fun voiceList(): List<Media>

    @Query("SELECT * FROM voice WHERE kind != 'voice'")
    suspend fun otherList(): List<Media>

    @Query("DELETE FROM voice WHERE id = :id")
    suspend fun delMedia(id: Long)

    @Query("DELETE FROM voice")
    suspend fun delAllMedia()

    @Insert
    suspend fun addDel(d: Del)

    @Query("SELECT * FROM dels ORDER BY id LIMIT 50")
    suspend fun pendingDels(): List<Del>

    @Query("DELETE FROM dels WHERE id = :id")
    suspend fun doneDel(id: Long)
}

private val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE messages ADD COLUMN synced INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE voice ADD COLUMN kind TEXT NOT NULL DEFAULT 'voice'")
        db.execSQL("ALTER TABLE voice ADD COLUMN synced INTEGER NOT NULL DEFAULT 0")
    }
}

private val MIGRATION_2_3 = object : Migration(2, 3) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS blocked (h TEXT NOT NULL, PRIMARY KEY(h))")
        db.execSQL("CREATE TABLE IF NOT EXISTS dels (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, type TEXT NOT NULL, a TEXT NOT NULL, b TEXT NOT NULL)")
    }
}

@Database(entities = [Msg::class, Media::class, Block::class, Del::class], version = 3, exportSchema = false)
abstract class Db : RoomDatabase() {
    abstract fun dao(): KeeperDao

    companion object {
        @Volatile private var inst: Db? = null
        fun get(c: Context): Db = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(c.applicationContext, Db::class.java, "keeper.db")
                .addMigrations(MIGRATION_1_2, MIGRATION_2_3)
                .build().also { inst = it }
        }
    }
}
