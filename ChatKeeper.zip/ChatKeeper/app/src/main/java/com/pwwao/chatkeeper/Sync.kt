package com.pwwao.chatkeeper

import android.content.Context
import androidx.work.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

object Prefs {
    private fun p(c: Context) = c.getSharedPreferences("keeper", Context.MODE_PRIVATE)
    fun url(c: Context): String = p(c).getString("url", "")!!.trim().trimEnd('/')
    fun key(c: Context): String = p(c).getString("key", "")!!.trim()
    fun save(c: Context, url: String, key: String) {
        p(c).edit().putString("url", url.trim()).putString("key", key.trim()).apply()
    }
    fun syncOn(c: Context): Boolean = p(c).getBoolean("syncOn", true)
    fun setSync(c: Context, on: Boolean) { p(c).edit().putBoolean("syncOn", on).apply() }
    fun firstRun(c: Context): Long {
        val sp = p(c)
        var t = sp.getLong("first", 0L)
        if (t == 0L) {
            t = System.currentTimeMillis()
            sp.edit().putLong("first", t).apply()
        }
        return t
    }
}

private const val MAX_UPLOAD = 20L * 1024 * 1024
private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

private fun post(url: String, len: Long, type: String, write: (OutputStream) -> Unit): Boolean {
    val c = URL(url).openConnection() as HttpURLConnection
    return try {
        c.requestMethod = "POST"
        c.doOutput = true
        c.connectTimeout = 20000
        c.readTimeout = 120000
        c.setFixedLengthStreamingMode(len)
        c.setRequestProperty("Content-Type", type)
        c.outputStream.use(write)
        c.responseCode == 200 && c.inputStream.bufferedReader().readText().trim().startsWith("ok")
    } catch (e: Exception) {
        false
    } finally {
        c.disconnect()
    }
}

class SyncWorker(c: Context, p: WorkerParameters) : CoroutineWorker(c, p) {
    override suspend fun doWork(): Result {
        val ctx = applicationContext
        val base = Prefs.url(ctx)
        val key = Prefs.key(ctx)
        if (!Prefs.syncOn(ctx) || base.isBlank() || key.isBlank()) return Result.success()
        val dao = Db.get(ctx).dao()

        // Deletes first, so removed items are removed from the server too
        while (true) {
            val dl = dao.pendingDels()
            if (dl.isEmpty()) break
            for (d in dl) {
                val url = "$base/delete.php?k=${enc(key)}&type=${enc(d.type)}&a=${enc(d.a)}&b=${enc(d.b)}"
                if (!post(url, 0, "text/plain") { }) return Result.retry()
                dao.doneDel(d.id)
            }
        }

        while (true) {
            val list = dao.unsyncedMsgs()
            if (list.isEmpty()) break
            val arr = JSONArray()
            list.forEach {
                arr.put(JSONObject().put("app", it.app).put("sender", it.sender).put("text", it.text)
                    .put("time", it.time).put("deleted", if (it.deleted) 1 else 0))
            }
            val body = arr.toString().toByteArray()
            if (!post("$base/messages.php?k=${enc(key)}", body.size.toLong(), "application/json") { it.write(body) })
                return Result.retry()
            dao.markMsgsSynced(list.map { it.id })
        }

        while (true) {
            val list = dao.unsyncedMedia()
            if (list.isEmpty()) break
            for (m in list) {
                val f = File(m.saved)
                if (f.exists() && f.length() <= MAX_UPLOAD) {
                    val q = "k=${enc(key)}&name=${enc(File(m.src).name)}&app=${enc(m.app)}&kind=${enc(m.kind)}&time=${m.time}"
                    val ok = post("$base/upload.php?$q", f.length(), "application/octet-stream") { o ->
                        f.inputStream().use { it.copyTo(o) }
                    }
                    if (!ok) return Result.retry()
                }
                dao.markMediaSynced(m.id)
            }
        }
        return Result.success()
    }
}

object Sync {
    private val net = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()

    fun soon(c: Context) {
        if (!Prefs.syncOn(c)) return
        WorkManager.getInstance(c).enqueueUniqueWork("sync-soon", ExistingWorkPolicy.KEEP,
            OneTimeWorkRequestBuilder<SyncWorker>().setConstraints(net).setInitialDelay(5, TimeUnit.SECONDS).build())
    }

    fun now(c: Context) {
        if (!Prefs.syncOn(c)) return
        WorkManager.getInstance(c).enqueueUniqueWork("sync-soon", ExistingWorkPolicy.REPLACE,
            OneTimeWorkRequestBuilder<SyncWorker>().setConstraints(net).build())
    }

    fun periodic(c: Context) {
        WorkManager.getInstance(c).enqueueUniquePeriodicWork("sync-periodic", ExistingPeriodicWorkPolicy.KEEP,
            PeriodicWorkRequestBuilder<SyncWorker>(15, TimeUnit.MINUTES).setConstraints(net).build())
    }
}
