package com.pwwao.chatkeeper

import android.content.Context
import java.io.File
import java.security.MessageDigest

object Hash {
    fun sha1(s: String): String =
        MessageDigest.getInstance("SHA-1").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

    // Same formula the server uses for messages.h
    fun msg(m: Msg) = sha1("${m.app}|${m.sender}|${m.time}|${m.text}")
    fun media(src: String) = "m|" + sha1(src)
}

object Deleter {
    private fun dao(ctx: Context) = Db.get(ctx).dao()

    suspend fun msg(ctx: Context, m: Msg) {
        val d = dao(ctx)
        d.block(Block(Hash.msg(m)))
        d.delMsg(m.id)
        d.addDel(Del(type = "msg", a = Hash.msg(m)))
        Sync.soon(ctx)
    }

    suspend fun chat(ctx: Context, app: String, sender: String) {
        val d = dao(ctx)
        d.chatMsgs(app, sender).forEach { d.block(Block(Hash.msg(it))) }
        d.delChat(app, sender)
        d.addDel(Del(type = "chat", a = app, b = sender))
        Sync.soon(ctx)
    }

    suspend fun media(ctx: Context, m: Media) {
        val d = dao(ctx)
        File(m.saved).delete()
        d.block(Block(Hash.media(m.src)))
        d.delMedia(m.id)
        // Same key the server builds in upload.php (sha1 of app + file name + time)
        d.addDel(Del(type = "media", a = Hash.sha1(m.app + File(m.src).name + m.time)))
        Sync.soon(ctx)
    }

    suspend fun voices(ctx: Context) = dao(ctx).voiceList().forEach { media(ctx, it) }
    suspend fun others(ctx: Context) = dao(ctx).otherList().forEach { media(ctx, it) }

    suspend fun all(ctx: Context) {
        val d = dao(ctx)
        d.allMsgs().forEach { d.block(Block(Hash.msg(it))) }
        d.allMedia().forEach {
            d.block(Block(Hash.media(it.src)))
            File(it.saved).delete()
        }
        d.delAllMsgs()
        d.delAllMedia()
        d.addDel(Del(type = "all"))
        Sync.soon(ctx)
    }
}
