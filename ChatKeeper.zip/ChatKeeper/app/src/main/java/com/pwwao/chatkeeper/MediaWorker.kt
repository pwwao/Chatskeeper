package com.pwwao.chatkeeper

import android.content.Context
import android.os.Environment
import androidx.work.*
import java.io.File
import java.util.concurrent.TimeUnit

private class Src(val prefix: String, val bases: List<String>)

private val SOURCES = mapOf(
    "WhatsApp" to Src("WhatsApp", listOf("Android/media/com.whatsapp/WhatsApp/Media", "WhatsApp/Media")),
    "WhatsApp Business" to Src("WhatsApp Business",
        listOf("Android/media/com.whatsapp.w4b/WhatsApp Business/Media", "WhatsApp Business/Media"))
)

private val KINDS = mapOf(
    "voice" to "Voice Notes",
    "image" to "Images",
    "video" to "Video",
    "doc" to "Documents",
    "audio" to "Audio"
)

private const val MAX_COPY = 200L * 1024 * 1024

class MediaWorker(c: Context, p: WorkerParameters) : CoroutineWorker(c, p) {
    override suspend fun doWork(): Result {
        if (!Environment.isExternalStorageManager()) return Result.success()
        val ctx = applicationContext
        val dao = Db.get(ctx).dao()
        val out = File(ctx.filesDir, "media").apply { mkdirs() }
        val root = Environment.getExternalStorageDirectory()
        val first = Prefs.firstRun(ctx)

        for ((app, src) in SOURCES) for (base in src.bases) for ((kind, suffix) in KINDS) {
            val dir = File(root, "$base/${src.prefix} $suffix")
            if (!dir.isDirectory) continue
            dir.walkTopDown()
                .filter { it.isFile && !it.name.startsWith(".") && it.length() in 1..MAX_COPY }
                .forEach { f ->
                    // Voice notes: import everything. Other media: only files newer than first run.
                    if (kind != "voice" && f.lastModified() < first) return@forEach
                    if (dao.hasMedia(f.absolutePath) > 0 || dao.isBlocked(Hash.media(f.absolutePath)) > 0) return@forEach
                    try {
                        val copy = File(out, "${System.nanoTime()}_${f.name}")
                        f.copyTo(copy, overwrite = true)
                        dao.addMedia(Media(src = f.absolutePath, saved = copy.absolutePath, app = app,
                            time = f.lastModified(), kind = kind))
                    } catch (_: Exception) { }
                }
        }
        Sync.soon(ctx)
        return Result.success()
    }
}

object Scan {
    fun soon(c: Context) {
        val wm = WorkManager.getInstance(c)
        wm.enqueueUniqueWork("vn-soon", ExistingWorkPolicy.KEEP,
            OneTimeWorkRequestBuilder<MediaWorker>().setInitialDelay(15, TimeUnit.SECONDS).build())
        wm.enqueueUniqueWork("vn-late", ExistingWorkPolicy.KEEP,
            OneTimeWorkRequestBuilder<MediaWorker>().setInitialDelay(2, TimeUnit.MINUTES).build())
    }

    fun periodic(c: Context) {
        WorkManager.getInstance(c).enqueueUniquePeriodicWork("vn-periodic", ExistingPeriodicWorkPolicy.KEEP,
            PeriodicWorkRequestBuilder<MediaWorker>(15, TimeUnit.MINUTES).build())
    }
}
